package com.gptlinux

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.widget.Toast
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import android.webkit.JavascriptInterface
import android.net.Uri
import android.graphics.Color
import android.webkit.WebResourceRequest
import android.os.Build

class MainActivity : Activity() {
    private lateinit var web: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.setBackgroundColor(Color.rgb(20, 22, 28))
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = false // no persistent browser storage needed
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = false
        web.settings.setSupportZoom(false)
        web.settings.builtInZoomControls = false
        web.settings.displayZoomControls = false
        web.setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = true
            @Suppress("DEPRECATION")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean = true
        }
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "GPTLinux")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface fun openUbuntu() {
            runOnUiThread { launchTermux("proot-distro login ubuntu") }
        }

        @JavascriptInterface fun runUbuntu(command: String) {
            if (command.isBlank()) return
            if (command.length > 12000) {
                runOnUiThread { Toast.makeText(this@MainActivity, "Command too long (12,000 character limit).", Toast.LENGTH_SHORT).show() }
                return
            }
            // Encode user command to base64 so it is passed as data, not shell syntax.
            val encoded = android.util.Base64.encodeToString(
                command.toByteArray(Charsets.UTF_8), android.util.Base64.NO_WRAP
            )
            val termuxCommand = "proot-distro login ubuntu -- bash -lc 'echo $encoded | base64 -d | bash'"
            runOnUiThread { launchTermux(termuxCommand) }
        }

        @JavascriptInterface fun setupInstructions() {
            runOnUiThread {
                val text = "In Termux run:\\npkg update && pkg install -y proot-distro\\nproot-distro install ubuntu\\nThen in Ubuntu: apt update && apt install -y xfce4 dbus-x11 xterm git python3 ffmpeg"
                android.app.AlertDialog.Builder(this@MainActivity)
                    .setTitle("Rootless Ubuntu setup")
                    .setMessage(text)
                    .setPositiveButton("Open Termux") { _, _ -> launchTermux("bash") }
                    .setNegativeButton("Close", null).show()
            }
        }

        @JavascriptInterface fun openUrl(url: String) {
            runOnUiThread {
                try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                catch (_: Exception) { Toast.makeText(this@MainActivity, "No browser found", Toast.LENGTH_SHORT).show() }
            }
        }
    }

    private fun launchTermux(command: String) {
        try {
            val intent = Intent()
            intent.setClassName("com.termux", "com.termux.app.RunCommandService")
            intent.action = "com.termux.RUN_COMMAND"
            intent.putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash")
            intent.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-lc", command))
            intent.putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home")
            intent.putExtra("com.termux.RUN_COMMAND_BACKGROUND", false)
            startService(intent)
            Toast.makeText(this, "Sent to Termux. Commands/output appear there.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Install Termux and enable allow-external-apps in termux.properties. " + (e.message ?: ""), Toast.LENGTH_LONG).show()
        }
    }

    override fun onPause() {
        web.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
    }

    override fun onDestroy() {
        web.removeJavascriptInterface("GPTLinux")
        web.stopLoading()
        web.loadUrl("about:blank")
        web.clearHistory()
        web.removeAllViews()
        web.destroy()
        super.onDestroy()
    }
}
