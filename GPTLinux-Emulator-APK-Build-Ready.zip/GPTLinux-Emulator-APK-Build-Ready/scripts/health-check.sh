#!/usr/bin/env bash
set -u
printf 'GPTLinux diagnostics\n====================\n'
printf 'Termux architecture: '; dpkg --print-architecture 2>/dev/null || uname -m
printf 'Available storage: '; df -h "$HOME" | awk 'NR==2 {print $4 " free of " $2}'
printf 'Memory: '; awk '/MemTotal|MemAvailable/ {printf "%s=%0.1f GiB ", $1, $2/1048576} END {print ""}' /proc/meminfo
if command -v proot-distro >/dev/null 2>&1; then proot-distro list; else echo 'proot-distro: not installed'; fi
if command -v proot-distro >/dev/null 2>&1 && proot-distro login ubuntu -- /bin/true >/dev/null 2>&1; then echo 'Ubuntu status: OK'; else echo 'Ubuntu status: unavailable/not installed'; fi
