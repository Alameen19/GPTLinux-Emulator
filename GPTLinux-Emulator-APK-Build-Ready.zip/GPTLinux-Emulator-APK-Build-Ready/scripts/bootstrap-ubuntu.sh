#!/usr/bin/env bash
# Run inside Termux (not inside Ubuntu). Safe to re-run; skips existing Ubuntu.
set -Eeuo pipefail
if ! command -v pkg >/dev/null 2>&1; then
  echo 'Run this script inside Termux, not inside Ubuntu.' >&2; exit 2
fi
pkg update
pkg install -y proot-distro coreutils
if proot-distro list | grep -Eq '^  ubuntu([[:space:]]|$)|^ubuntu([[:space:]]|$)'; then
  echo 'Ubuntu appears in the installed distro list; checking login...'
  if ! proot-distro login ubuntu -- /bin/true; then
    echo 'Ubuntu is listed but failed to start. Check proot-distro list and logs.' >&2; exit 1
  fi
else
  proot-distro install ubuntu
fi
proot-distro login ubuntu -- bash -lc 'export DEBIAN_FRONTEND=noninteractive; apt-get update; apt-get install -y --no-install-recommends ca-certificates bash coreutils procps nano git python3 ffmpeg; apt-get clean; rm -rf /var/lib/apt/lists/*'
echo 'GPTLinux base environment is ready. Optional desktop packages are installed separately.'
