#!/usr/bin/env bash
# Run from Termux. Installs an optional XFCE desktop inside Ubuntu.
set -Eeuo pipefail
command -v proot-distro >/dev/null 2>&1 || { echo 'Install proot-distro in Termux first.' >&2; exit 2; }
proot-distro login ubuntu -- bash -lc 'export DEBIAN_FRONTEND=noninteractive; apt-get update; apt-get install -y --no-install-recommends xfce4 dbus-x11 xterm; apt-get clean; rm -rf /var/lib/apt/lists/*'
echo 'XFCE packages installed. To display them on Android, install/configure the Termux:X11 Android app and Termux package separately.'
