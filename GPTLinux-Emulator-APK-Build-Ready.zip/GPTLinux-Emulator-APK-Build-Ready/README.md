# GPTLinux Emulator — optimized rootless source

GPTLinux is a touch-first launcher for a **real Ubuntu user-space environment** hosted by Termux + `proot-distro` on Android. A Windows companion uses Ubuntu through WSL. This package contains source and setup scripts; it does **not** contain a precompiled APK/EXE, Linux kernel, or bundled Ubuntu image.

## What is optimized

- **No nested VM overhead:** uses Termux/proot instead of trying to emulate an entire PC on an Android phone.
- **Minimal base install:** `--no-install-recommends`, package cache cleanup, and XFCE kept optional to save storage/RAM.
- **Idempotent bootstrap:** `scripts/bootstrap-ubuntu.sh` checks the existing Ubuntu environment before reinstalling.
- **Diagnostics:** `scripts/health-check.sh` reports architecture, storage, memory and Ubuntu availability.
- **Lean Android shell:** WebView hardware layer, no unnecessary DOM storage/zoom, URL navigation blocked in the bridge-enabled WebView, command-length limit, and lifecycle cleanup.
- **Separate GUI layer:** XFCE can be installed only if desired, because a display server consumes additional memory and battery.

## Android setup

1. Install Termux from a trusted official distribution source and open it once.
2. Extract this project or copy the `scripts` folder into Termux storage. If copied to shared storage, run `termux-setup-storage` first.
3. In Termux, the basic manual setup is:
   ```bash
   pkg update && pkg upgrade -y
   pkg install -y proot-distro
   proot-distro install ubuntu
   proot-distro login ubuntu -- bash -lc 'apt-get update && apt-get install -y --no-install-recommends ca-certificates bash coreutils procps nano git python3 ffmpeg && apt-get clean && rm -rf /var/lib/apt/lists/*'
   ```
   Alternatively run `bash scripts/bootstrap-ubuntu.sh` from the directory containing the scripts.
4. To let GPTLinux launch Termux commands, edit `~/.termux/termux.properties` and set `allow-external-apps = true`, then restart Termux. Grant the requested Android permission only if you trust this app.
5. Build and install the APK using the steps below. Tap **Open Ubuntu terminal**. Commands are delegated to Termux; output appears in the Termux terminal, not embedded in GPTLinux. This is an Android sandbox limitation of this starter design.

### Optional XFCE desktop

Run `bash scripts/install-xfce.sh` from Termux (or manually install `xfce4 dbus-x11 xterm` inside Ubuntu). Then install/configure the Termux:X11 Android app and Termux-side package from that project's supported release sources. The display/session setup varies by device. XFCE is optional because it uses significantly more RAM and storage than a CLI environment.

Run `bash scripts/health-check.sh` in Termux to inspect basic status. For best battery and responsiveness, close desktop sessions when using command-line tools and avoid installing multiple large desktop environments.

## Build Android APK

Requirements: Android Studio, JDK 17, Android SDK 35 and internet access.

1. Open the `android/` folder in Android Studio.
2. Allow Gradle to sync.
3. Use **Build > Build APK(s)**.
4. Debug APK output: `android/app/build/outputs/apk/debug/app-debug.apk`.

The project does not include a Gradle wrapper or a prebuilt APK. Build it locally; this archive has not been compiled or device-tested here.

## Windows companion (WSL)

Install WSL Ubuntu from elevated PowerShell:
```powershell
wsl --install -d Ubuntu
```
Then install the .NET 8 SDK and publish from `windows/`:
```powershell
dotnet publish -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true
```
Output is expected in `windows/bin/Release/net8.0-windows/win-x64/publish/GPTLinux.Windows.exe`. This is a launcher for WSL, not a bundled virtual machine. ARM64 Windows can use `-r win-arm64`.

## Capabilities and limits

This provides a Linux **userland**, not a full virtual machine or a new Linux kernel. It does not replace Android. It is best suited to shell tools, Git, Python and FFmpeg. GPU acceleration, OBS, Steam/Proton, PC games, professional editing, audio, and all GUI apps are not guaranteed in proot; use native Android apps for performance-sensitive mobile workflows. Do not run commands you do not trust: the command box executes real shell commands in Ubuntu.

## Build the APK in GitHub Actions (no Android SDK on your computer)

This repository includes `.github/workflows/build-android-apk.yml`. Upload/push the extracted project to a GitHub repository, then open **Actions → Build GPTLinux APK → Run workflow**. When the run succeeds, open that run and download the `GPTLinux-Emulator-debug-apk` artifact. Extract it to get `app-debug.apk`. This is a debug APK, suitable for testing; it is not a Play Store release-signed APK.
