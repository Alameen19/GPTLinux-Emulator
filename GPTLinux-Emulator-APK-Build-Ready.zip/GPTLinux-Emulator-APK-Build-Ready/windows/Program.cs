using System.Diagnostics;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace GPTLinux.Windows;

internal static class Program
{
    [STAThread]
    static void Main() { ApplicationConfiguration.Initialize(); Application.Run(new MainForm()); }
}
public sealed class MainForm : Form
{
    readonly TextBox output = new() { Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Both, Dock = DockStyle.Fill,
        BackColor = Color.FromArgb(18,20,25), ForeColor = Color.FromArgb(210,240,220), Font = new Font("Consolas",10), WordWrap = false };
    readonly TextBox command = new() { Dock = DockStyle.Fill, Font = new Font("Consolas",11), PlaceholderText = "Linux command to run in WSL Ubuntu…" };
    readonly Button run = new() { Text = "Run", AutoSize = true };
    readonly Button check = new() { Text = "Check WSL", AutoSize = true };
    public MainForm()
    {
        Text = "GPTLinux — Ubuntu via WSL"; Width = 1000; Height = 700; MinimumSize = new Size(620,450);
        BackColor = Color.FromArgb(32,35,42);
        var top = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 48, Padding = new Padding(8), WrapContents = false };
        top.Controls.Add(new Label { Text = "GPTLinux", AutoSize = true, ForeColor = Color.White, Font = new Font("Segoe UI",13,FontStyle.Bold), Padding = new Padding(0,4,12,0) });
        top.Controls.Add(check);
        var bottom = new TableLayoutPanel { Dock = DockStyle.Bottom, Height = 54, ColumnCount = 2, Padding = new Padding(8) };
        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100)); bottom.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
        bottom.Controls.Add(command,0,0); bottom.Controls.Add(run,1,0);
        Controls.Add(output); Controls.Add(bottom); Controls.Add(top);
        run.Click += async (_,_) => await RunLinuxCommand();
        command.KeyDown += async (_,e) => { if(e.KeyCode==Keys.Enter){e.SuppressKeyPress=true; await RunLinuxCommand();} };
        check.Click += async (_,_) => await RunProcess("wsl.exe","--list --verbose");
        Append("GPTLinux Windows companion. Commands run in your installed WSL Ubuntu.\\r\\nInstall WSL from elevated PowerShell: wsl --install -d Ubuntu");
    }
    void Append(string s) { output.AppendText(s + Environment.NewLine); }
    async Task RunLinuxCommand()
    {
        var cmd=command.Text.Trim(); if(cmd.Length==0)return;
        command.Clear(); Append("$ "+cmd);
        var encoded=Convert.ToBase64String(Encoding.UTF8.GetBytes(cmd));
        // WSL bash decodes the supplied command string before execution.
        await RunProcess("wsl.exe",$"-d Ubuntu -- bash -lc \"echo {encoded} | base64 -d | bash\"");
    }
    async Task RunProcess(string file,string args)
    {
        run.Enabled=false;
        try {
            var psi=new ProcessStartInfo(file,args){UseShellExecute=false,RedirectStandardOutput=true,RedirectStandardError=true,CreateNoWindow=true};
            using var p=new Process{StartInfo=psi}; p.Start();
            var stdout=p.StandardOutput.ReadToEndAsync(); var stderr=p.StandardError.ReadToEndAsync(); await p.WaitForExitAsync();
            Append(await stdout); var err=await stderr; if(!string.IsNullOrWhiteSpace(err))Append("[stderr] "+err); Append($"[exit {p.ExitCode}]");
        } catch(Exception ex){Append("Unable to start WSL: "+ex.Message);}
        finally{run.Enabled=true;}
    }
}
